#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#define PORT 10001
#include "Stock.h"



typedef struct ball ball;
struct ball{int ID; char IPjoueur[32]; int chrono};

char IProbot[32]="127.0.0.1"; // adresse provisoire, sera remplacée par l'IP du robot



// 1- fonction récupération logs 


// 2- fonction de parsage

// 3 - Communication RPC avec le gestionnaire de stock
char*
distributionballon_1(char *host, char *IP)
{
	CLIENT *clnt;
	reponse1  *result_1;
	data1  distribution_1_arg;

#ifndef	DEBUG
	clnt = clnt_create (host, distributionballon, VERSION_UN, "udp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
#endif	/* DEBUG */
	strcpy(distribution_1_arg.IPjoueur, IP);
	result_1 = distribution_1(&distribution_1_arg, clnt);
	if (result_1 == (reponse1 *) NULL) {
		clnt_perror (clnt, "call failed");
	}
#ifndef	DEBUG
	clnt_destroy (clnt);
#endif	 /* DEBUG */
	return result_1->cleballon;
}


int
validationballon_1(char *host, char *cleballon)
{
	CLIENT *clnt;
	reponse2  *result_1;
	data2  validation_1_arg;

#ifndef	DEBUG
	clnt = clnt_create (host, validationballon, VERSION_UN, "udp");
	if (clnt == NULL) {
		clnt_pcreateerror (host);
		exit (1);
	}
#endif	/* DEBUG */
	strcpy(validation_1_arg.cleballon, cleballon);
	result_1 = validation_1(&validation_1_arg, clnt);
	if (result_1 == (reponse2 *) NULL) {
		clnt_perror (clnt, "call failed");
	}
#ifndef	DEBUG
	clnt_destroy (clnt);
#endif	 /* DEBUG */
	return result_1->ok;
}







int main(){

	// réception des logs

	///parsage

	//initialisations sockets
	int sock;
    struct sockaddr_in server;
    char message[1000] , server_reply[2000];
     
   
	//boucle infinie
	 for(;;){
	 	
	 	//if passage RFID commment le matérialiser ?
	 	// provisoirement : récupérer l'adresse IP du robot à la main

	 	printf("Rentrez l'adresse IP du robot qui veut recevoir le ballon :\n");

	 	scanf("%s",&IProbot);


	 	 //Create socket
	    sock = socket(AF_INET , SOCK_STREAM , 0);
	    if (sock == -1)
	    {
	        printf("Could not create socket");
	    }
	    puts("Socket created");
	     
	    server.sin_addr.s_addr = inet_addr(IProbot);
	    server.sin_family = AF_INET;
	    server.sin_port = htons( 10001 );


	    //Connexion au serveur robot
	    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
	    {
	        perror("connect failed. Error");
	        return 1;
	    }
	     
	    puts("Connected\n");

	  	/* Reception de donnees du serveur ( Réponse à la question : Avez vous un ballon ?)*/
	  	char buffer[256];
	  	recv(sock, buffer, 256, 0);
	  	printf("Recu : %s\n", buffer);

	  	/* Initialisation du test ballon */
	  	int BallonValide= 0;
	  	char* ballonRecu[256];

	  	/* Test ballon valide*/

	  	char buffer2[256] = "pas de ballon";

	  	int res = strcmp(buffer, buffer2);

	  	//si il y a un ballon dans le fichier Ballon.txt, on regarde s'il est encore valide
	  	if(res != 0){
	    	  int reponse = validationballon_1("localhost",buffer); // libèrera le ballon si il est dans le tableau.
	    }
	    int cleballon = distributionballon_1("localhost",IProbot);
	    send(sock, cleballon, 32, 0); // envoie le ballon créé au robot

	}

	return 0;

}