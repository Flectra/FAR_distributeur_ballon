# FAR_distributeur_ballon

Les étapes du processus :

1. On attend qu'un robot entre dans la zone de distribution (ouverture de la connexion)
2. on attend la requête "ballon" du robot
Section critique
3. on vérifie qu'un ballon est disponible 
4. on envoie une réponse au robot : ballon, ou non
5. on ferme la connexion 
