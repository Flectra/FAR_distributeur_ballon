#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//télécherger et installer la librairie Openssl 
#include "openssl/rsa.h"
#include "openssl/pem.h"
#include "time.h"

// à vérifier !
#define PORT 10000


typedef struct ball ball;
struct ball{int ID; char* IPjoueur; struct tm Dchrono};

char* IP="127.0.0.1"; // adresse provisoire, sera remplacée par l'IP du robot

int code = 0; // ne pas oublier de l'incrémenter

/*function qui génère un ballon à distribuer*/
 ball GenerateBall(char* IP){

 	ball Ballon;
 	Ballon.IPjoueur = IP;
 	//Initialisation de variables et des structures pour la date
	time_t temps;
	struct tm date;

	//Récupération de la date actuelle
	time(&temps);
	date=*localtime(&temps);
 	Ballon.Dchrono = date;

  Ballon.ID = code;

}

/*fonction qui sérialise un ballon*/

char* Serialize(ball Ballon){
  char str1[256] = Ballon.ID+'0';
  char str2 = Ballon.IP;
  strcat(str1,".");
  strcat(str1,str2);
  strcat(str1,".");
  char str3[128];
  strftime(str3,128,"%H-%M-%S",&Ballon.Dchrono);
  strcat(str1,str3);
  return str1;
}


/*fonction de cryptage d'un ballon*/

  char* Encode(char* codecrypt){

  }

/*const int kBits = 1024;
const int kExp = 3;*/


//strftime(s,128, "Heure:%H, Minute:%M, Seconde:%S",&date);
//system(s);

int sock;


int main(void) {
  
  struct sockaddr_in sin;

  /* Creation de la socket */
  sock = socket(AF_INET, SOCK_STREAM, 0);
 
  /* Configuration de la connexion */
  sin.sin_addr.s_addr = inet_addr("127.0.0.1"); /*par défaut pour l'instant mais devra correspondre à l'IP du robot concerné*/
  sin.sin_family = AF_INET;
  sin.sin_port = htons(PORT);
 
  /* Tentative de connexion au serveur */
  connect(sock, (struct sockaddr*)&sin, sizeof(sin));
  printf("Connexion a %s sur le port %d\n", inet_ntoa(sin.sin_addr),
         htons(sin.sin_port));

  /* Reception de donnees du serveur ( Réponse à la question : Avez vous un ballon ?)*/
  char buffer[32] = "";
  recv(sock, buffer, 32, 0);
  printf("Recu : %s\n", buffer);

  // teste si le robot a un ballon et si il est valide ou non
  bool testBall;
  if
  // teste si le robot a un ballon ou non
  if (strcmp(const char *buffer, "pas de ballon")==0){}



  for(;;) {
    /* Envoi de donnees au serveur */
    printf("Donnees a envoyer au serveur : ");
    fgets(buffer, 32, stdin); /* remplacer par buffer  = key (ID, IP, DChrono)
    char *pos = strchr(buffer, '\n');
    *pos = '\0';
    send(sock, buffer, 32, 0);
  }//for

  return EXIT_SUCCESS;

}//main

